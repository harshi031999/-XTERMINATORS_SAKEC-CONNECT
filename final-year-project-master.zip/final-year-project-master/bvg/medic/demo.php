<form action="login.php" method="POST">
<input type="text" value="Chinmay" name="username">
<input type="password" value="chinmay" name="password">
<input type="submit" >
</form>